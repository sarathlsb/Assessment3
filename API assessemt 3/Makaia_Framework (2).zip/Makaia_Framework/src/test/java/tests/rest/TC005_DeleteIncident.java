package tests.rest;

import java.io.File;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;


public class TC005_DeleteIncident extends RESTAssuredBase{
	
	@BeforeTest//Reporting
	public void setValues() {
		testCaseName = "Delete a new Incident (REST)";
		testDescription = "Delete a new Incident and Verify";
		nodes = "Incident";
		authors = "Sarath";
		category = "REST";
		//dataProvider
		
	}

	@Test( dependsOnMethods = "tests.rest.TC004_PutIncident.putIncident")
	public void deleteIncident() {		
				
		Response response = delete( "incident/"+sysID);
		response.prettyPrint();
		
		
		verifyResponseCode(response, 204);
		
		
	}


}




















